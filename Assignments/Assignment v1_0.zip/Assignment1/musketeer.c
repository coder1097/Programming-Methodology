#ifndef _MUSKETEER_C_
#define _MUSKETEER_C_

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <stdbool.h>

float computeSurvivalRate(int *hp1, int* hp2, int* q1, int* q2, int *d)
{
	// Write your code here.Please!
	return -1.0;
}

#endif
